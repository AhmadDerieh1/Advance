package edu.najah.cap.export;

import edu.najah.cap.iam.UserService;

public class ExportFactory {
    private UserService userService;

    // Constructor to inject UserService
    public ExportFactory(UserService userService) {
        this.userService = userService;
    }

    public DataExporter createExport(String type) {
        if (type.equals("PDF")) {
            return new DirectExporter(userService);
        }

        throw new IllegalArgumentException("Unsupported export type: " + type);
    }
}
