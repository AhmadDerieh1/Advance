package edu.najah.cap.export;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import edu.najah.cap.iam.UserProfile;
import edu.najah.cap.iam.UserService;

import javax.xml.namespace.QName;
import java.io.FileOutputStream;

public class DirectExporter implements DataExporter {
    private UserService userService;
    private String userName;
    public DirectExporter(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void exportData(String userName) {
    this.userName =userName;
    exportUserProfileToPdf(userName);

    }


    public void exportUserProfileToPdf(String username) {
        Document document = new Document();
        UserProfile userProfile = userService.getUser(username);
        try {
            System.out.println("fack");
            PdfWriter.getInstance(document, new FileOutputStream("UserName_" + username.replaceAll("\\s+", "_") + ".pdf"));
            document.open();
            document.add(new Paragraph("UserName: " + userProfile.getUserName()));
            document.add(new Paragraph("First Name:" + userProfile.getFirstName()));
            document.add(new Paragraph("Last Name:" + userProfile.getLastName()));
            document.add(new Paragraph("Phone number:" + userProfile.getPhoneNumber()));
            document.add(new Paragraph("Email: " + userProfile.getEmail()));
            document.add(new Paragraph("Password:" + userProfile.getPassword()));
            document.add(new Paragraph("Role:" + userProfile.getRole()));
            document.add(new Paragraph("Department:" + userProfile.getDepartment()));
            document.add(new Paragraph("Department:" + userProfile.getDepartment()));
            document.add(new Paragraph("Organization:" + userProfile.getOrganization()));
            document.add(new Paragraph("Country:" + userProfile.getCountry()));
            document.add(new Paragraph("City:" + userProfile.getCity()));
            document.add(new Paragraph("Street:" + userProfile.getStreet()));
            document.add(new Paragraph("Post code:" + userProfile.getPostalCode()));
            document.add(new Paragraph("Building:" + userProfile.getBuilding()));
            document.add(new Paragraph("User type:" + userProfile.getUserType()));




        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            if (document != null) {
                document.close();
            }
        }
    }
}
