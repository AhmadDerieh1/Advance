package edu.najah.cap.export;

public class ZipExporter implements DataExporter {
    @Override
    public void exportData(String userName) {
        // Code to convert a zip file containing PDF files
    }

}
