package edu.najah.cap.export;

public class ZipExporter implements DataExporter {
    @Override
    public void exportData(String userName) {

    }

}
