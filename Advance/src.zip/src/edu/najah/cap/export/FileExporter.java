package edu.najah.cap.export;

public class FileExporter implements DataExporter {
    @Override
    public void exportData(String userName) {
        // Code to export data and upload it to a specified file storage service
    }
}
