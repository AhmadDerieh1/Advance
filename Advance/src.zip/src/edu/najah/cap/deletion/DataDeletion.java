package edu.najah.cap.deletion;

public class DataDeletion {

    private static DataDeletion instance;

    private DataDeletion() {
        // Private constructor to prevent instantiation
    }

    private static DataDeletion getInstance() {
        if (instance == null) {
            synchronized (DataDeletion.class) {
                if (instance == null) {
                    instance = new DataDeletion();
                }
            }
        }
        return instance;
    }
    public void softDeleteData(String dataId) {
        // Code to soft delete data with the given dataId
    }
    public void hardDeleteData(String dataId) {
        // Code to hard delete data with the given dataId
    }

}
