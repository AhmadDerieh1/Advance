package edu.najah.cap.exceptions;

public class SystemBusyException extends Exception {
    public SystemBusyException(String message) {
        super(message);
    }
}
