package edu.najah.cap.iam;

public enum UserType {
    NEW_USER,REGULAR_USER,PREMIUM_USER
}
