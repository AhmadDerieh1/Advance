package edu.najah.cap.export;

public interface DataExporter {
    void exportData(String userName);
}
